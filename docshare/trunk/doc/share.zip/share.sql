if exists(select 1 from sys.sysforeignkey where role='FK_COLLECTI_REFERENCE_READER') then
    alter table collection
       delete foreign key FK_COLLECTI_REFERENCE_READER
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_COLLECTI_REFERENCE_DOCUMENT') then
    alter table collection
       delete foreign key FK_COLLECTI_REFERENCE_DOCUMENT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_COMMENT_REFERENCE_DOCUMENT') then
    alter table "comment"
       delete foreign key FK_COMMENT_REFERENCE_DOCUMENT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_COMMENT_REFERENCE_READER') then
    alter table "comment"
       delete foreign key FK_COMMENT_REFERENCE_READER
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_DOC_TO_T_REFERENCE_DOCUMENT') then
    alter table doc_to_tag
       delete foreign key FK_DOC_TO_T_REFERENCE_DOCUMENT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_DOC_TO_T_REFERENCE_TAG') then
    alter table doc_to_tag
       delete foreign key FK_DOC_TO_T_REFERENCE_TAG
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_DOWNLOAD_REFERENCE_DOCUMENT') then
    alter table download_info
       delete foreign key FK_DOWNLOAD_REFERENCE_DOCUMENT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_DOWNLOAD_REFERENCE_READER') then
    alter table download_info
       delete foreign key FK_DOWNLOAD_REFERENCE_READER
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRIVATE_REFERENCE_READER') then
    alter table private
       delete foreign key FK_PRIVATE_REFERENCE_READER
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRIVATE_REFERENCE_DOCUMENT') then
    alter table private
       delete foreign key FK_PRIVATE_REFERENCE_DOCUMENT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_READER_T_REFERENCE_READER') then
    alter table reader_to_tag
       delete foreign key FK_READER_T_REFERENCE_READER
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_READER_T_REFERENCE_TAG') then
    alter table reader_to_tag
       delete foreign key FK_READER_T_REFERENCE_TAG
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SCORE_REFERENCE_DOCUMENT') then
    alter table score
       delete foreign key FK_SCORE_REFERENCE_DOCUMENT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SCORE_REFERENCE_READER') then
    alter table score
       delete foreign key FK_SCORE_REFERENCE_READER
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SHARE_TI_REFERENCE_DOCUMENT') then
    alter table share_times
       delete foreign key FK_SHARE_TI_REFERENCE_DOCUMENT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_SHARE_TI_REFERENCE_READER') then
    alter table share_times
       delete foreign key FK_SHARE_TI_REFERENCE_READER
end if;

if exists(
   select 1 from sys.systable 
   where table_name='collection'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table collection
end if;

if exists(
   select 1 from sys.systable 
   where table_name='comment'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table "comment"
end if;

if exists(
   select 1 from sys.systable 
   where table_name='doc_to_tag'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table doc_to_tag
end if;

if exists(
   select 1 from sys.systable 
   where table_name='document'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table document
end if;

if exists(
   select 1 from sys.systable 
   where table_name='download_info'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table download_info
end if;

if exists(
   select 1 from sys.systable 
   where table_name='private'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table private
end if;

if exists(
   select 1 from sys.systable 
   where table_name='reader'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table reader
end if;

if exists(
   select 1 from sys.systable 
   where table_name='reader_to_tag'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table reader_to_tag
end if;

if exists(
   select 1 from sys.systable 
   where table_name='score'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table score
end if;

if exists(
   select 1 from sys.systable 
   where table_name='share_times'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table share_times
end if;

if exists(
   select 1 from sys.systable 
   where table_name='tag'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table tag
end if;

/*==============================================================*/
/* Table: collection                                            */
/*==============================================================*/
create table collection 
(
   id                   int                            not null,
   doc_id               int                            null,
   reader_id            int                            null,
   collect_time         bigint                         null,
   constraint PK_COLLECTION primary key clustered (id)
);

/*==============================================================*/
/* Table: "comment"                                             */
/*==============================================================*/
create table "comment" 
(
   id                   int                            not null,
   doc_id               int                            null,
   reader_id            int                            null,
   content              varchar(256)                   null,
   post_time            int                            null,
   constraint PK_COMMENT primary key clustered (id)
);

/*==============================================================*/
/* Table: doc_to_tag                                            */
/*==============================================================*/
create table doc_to_tag 
(
   id                   int                            not null,
   doc_id               int                            null,
   tag_id               int                            null,
   constraint PK_DOC_TO_TAG primary key clustered (id)
);

/*==============================================================*/
/* Table: document                                              */
/*==============================================================*/
create table document 
(
   id                   int                            not null,
   title                varchar(32)                    null,
   disc                 varchar(140)                   null,
   upload_time          long                           null,
   constraint PK_DOCUMENT primary key clustered (id)
);

/*==============================================================*/
/* Table: download_info                                         */
/*==============================================================*/
create table download_info 
(
   id                   int                            not null,
   doc_id               int                            null,
   reader_id            int                            null,
   download_times       int                            null,
   "time"               long                           null,
   constraint PK_DOWNLOAD_INFO primary key clustered (id)
);

/*==============================================================*/
/* Table: private                                               */
/*==============================================================*/
create table private 
(
   id                   int                            not null,
   reader_id            int                            null,
   doc_id               int                            null,
   private              bit                            null,
   constraint PK_PRIVATE primary key clustered (id)
);

/*==============================================================*/
/* Table: reader                                                */
/*==============================================================*/
create table reader 
(
   id                   int                            not null,
   name                 varchar(16)                    null,
   email                varchar(32)                    null,
   password             varchar(16)                    null,
   constraint PK_READER primary key clustered (id),
   constraint AK_ID_READER unique ()
);

/*==============================================================*/
/* Table: reader_to_tag                                         */
/*==============================================================*/
create table reader_to_tag 
(
   id                   int                            not null,
   tag_id               int                            null,
   reader_id            int                            null,
   constraint PK_READER_TO_TAG primary key clustered (id)
);

/*==============================================================*/
/* Table: score                                                 */
/*==============================================================*/
create table score 
(
   id                   int                            not null,
   doc_id               int                            null,
   reader_id            int                            null,
   score                int                            null,
   constraint PK_SCORE primary key clustered (id)
);

/*==============================================================*/
/* Table: share_times                                           */
/*==============================================================*/
create table share_times 
(
   id                   int                            not null,
   doc_id               int                            null,
   rea_id               int                            null,
   share_times          int                            null,
   "time"               long                           null,
   constraint PK_SHARE_TIMES primary key clustered (id)
);

/*==============================================================*/
/* Table: tag                                                   */
/*==============================================================*/
create table tag 
(
   id                   int                            not null,
   tag_name             varchar(16)                    null,
   constraint PK_TAG primary key clustered (id)
);

alter table collection
   add constraint FK_COLLECTI_REFERENCE_READER foreign key (reader_id)
      references reader (id)
      on update restrict
      on delete restrict;

alter table collection
   add constraint FK_COLLECTI_REFERENCE_DOCUMENT foreign key (doc_id)
      references document (id)
      on update restrict
      on delete restrict;

alter table "comment"
   add constraint FK_COMMENT_REFERENCE_DOCUMENT foreign key (doc_id)
      references document (id)
      on update restrict
      on delete restrict;

alter table "comment"
   add constraint FK_COMMENT_REFERENCE_READER foreign key (reader_id)
      references reader (id)
      on update restrict
      on delete restrict;

alter table doc_to_tag
   add constraint FK_DOC_TO_T_REFERENCE_DOCUMENT foreign key (doc_id)
      references document (id)
      on update restrict
      on delete restrict;

alter table doc_to_tag
   add constraint FK_DOC_TO_T_REFERENCE_TAG foreign key (tag_id)
      references tag (id)
      on update restrict
      on delete restrict;

alter table download_info
   add constraint FK_DOWNLOAD_REFERENCE_DOCUMENT foreign key (doc_id)
      references document (id)
      on update restrict
      on delete restrict;

alter table download_info
   add constraint FK_DOWNLOAD_REFERENCE_READER foreign key (reader_id)
      references reader (id)
      on update restrict
      on delete restrict;

alter table private
   add constraint FK_PRIVATE_REFERENCE_READER foreign key (reader_id)
      references reader (id)
      on update restrict
      on delete restrict;

alter table private
   add constraint FK_PRIVATE_REFERENCE_DOCUMENT foreign key (doc_id)
      references document (id)
      on update restrict
      on delete restrict;

alter table reader_to_tag
   add constraint FK_READER_T_REFERENCE_READER foreign key (reader_id)
      references reader (id)
      on update restrict
      on delete restrict;

alter table reader_to_tag
   add constraint FK_READER_T_REFERENCE_TAG foreign key (tag_id)
      references tag (id)
      on update restrict
      on delete restrict;

alter table score
   add constraint FK_SCORE_REFERENCE_DOCUMENT foreign key (doc_id)
      references document (id)
      on update restrict
      on delete restrict;

alter table score
   add constraint FK_SCORE_REFERENCE_READER foreign key (reader_id)
      references reader (id)
      on update restrict
      on delete restrict;

alter table share_times
   add constraint FK_SHARE_TI_REFERENCE_DOCUMENT foreign key (doc_id)
      references document (id)
      on update restrict
      on delete restrict;

alter table share_times
   add constraint FK_SHARE_TI_REFERENCE_READER foreign key (rea_id)
      references reader (id)
      on update restrict
      on delete restrict;
